# Assignment-NO-3
In this project I used data science to determine who is better at driving male or female so for this reason I gathered data about accidents in America and after comparing the count of causes of accidents with the sex of drivers we concluded that females are better drivers.
